#!/bin/bash
#
# Upload the App to a Red Pitaya from a PC.
#
#   ./upload_app.sh [-w] [-p port_number] rp-XXXXXX.local
#
# Steps: create an SSH key if there is none, copy it to the Red Pitaya (ssh-copy-id), make the
# file system writable and copy the App to /opt/redpitaya/www/apps/<APP>/ (or only the web
# interface with -w).

APP="lock_in+pid_plus"
APPS_DIR="/opt/redpitaya/www/apps"
APP_DIR="${APPS_DIR}/${APP}"

# The file system is made writable with the rw script of the OS, as the Makefile upload targets:
# /opt/redpitaya/sbin/rw in Ecosystem 2.0, /boot/sbin/rw in 0.9x (it needs PATH_REDPITAYA exported).
RP_RW='export PATH_REDPITAYA=/opt/redpitaya ; if [ -x /opt/redpitaya/sbin/rw ] ; then /opt/redpitaya/sbin/rw ; else /boot/sbin/rw ; fi'

SSH_KEY="${HOME}/.ssh/id_rsa"


# ---- Messages: English, or Spanish when LANG is es_* -----------------------------------------

L=0
if [[ $LANG = *"es_"* ]]; then
  echo "Idioma español"
  L=1
fi

# msg "english text" "texto en español"   (echo -e: \n is interpreted)
msg() {
  local txt=("$1" "$2")
  echo -e "${txt[$L]}"
}

usage() {
  echo "${0} [-w] [-p port_number] rp-XXXXXX.local "
  echo "  -w              upload only the web interface (index.html, css, js)"
  echo "  -p port_number  SSH port (default 22)"
}


# ---- Arguments ---------------------------------------------------------------------------------

port_number=22
webonly=false

OPTIND=1
while getopts "wp:h?" opt; do
  case "$opt" in
    p)  port_number=$OPTARG
        echo "port_number: $port_number"
        ;;
    w)  webonly=true
        echo "webonly: $webonly"
        ;;
    h|\?)
        usage
        exit 0
        ;;
  esac
done
shift $((OPTIND-1))
[ "${1:-}" = "--" ] && shift

if [ $# -lt 1 ]; then
  msg "You must provide the Red Pitaya hostname or IP:\n  ./upload_app.sh rp-XXXXXX.local\n" \
      "Debes especificar el nombre de host o la dirección IP de la Red Pitaya:\n  ./upload_app.sh rp-XXXXXX.local\n"
  exit
fi
RPIP="$1"

RPOPTS=(-l root -p "${port_number}")
RPSCP=(-P "${port_number}")


# ---- Error handling: stop at the first failing command and report it --------------------------

set -e
trap 'rc=$?; msg "\n  \"${BASH_COMMAND}\" command failed with exit code ${rc}.\n" \
                 "\n  El comando \"${BASH_COMMAND}\" falló con el código de ERROR: ${rc}.\n"' ERR

# Do not use an SSH agent: the key in ${SSH_KEY} is used
export SSH_AUTH_SOCK=0


# ---- Start -------------------------------------------------------------------------------------

msg "RedPitaya hostname:  ${RPIP}" \
    "Nombre de la Red Pitaya:  ${RPIP}"

# SSH key of this PC
if [ ! -f "${SSH_KEY}" ]; then
  msg "\nYou don't have SSH KEY. Creating one automatically. \n" \
      "\nNo tenés una llave SSH. Creando una automáticamente. \n"
  echo "
  mkdir -p $HOME/.ssh/
  chmod 700 $HOME/.ssh
  ssh-keygen -t rsa -P \"\" -f ${SSH_KEY}
  chmod 600 ${SSH_KEY}
  "
  mkdir -p "$HOME/.ssh/"
  chmod 700 "$HOME/.ssh"
  ssh-keygen -t rsa -P "" -f "${SSH_KEY}"
  chmod 600 "${SSH_KEY}"
fi

# Work from the folder that holds the App files: the package has them in ./${APP}/ next to this
# script; in the source tree the script is already inside the App folder.
cd "$(dirname "$0")"
if [ -d "./${APP}" ]; then
  cd "${APP}"
  echo "cd ${APP}"
fi

echo "$APP"

# Files copied to the board: the whole App, or only the web interface (-w).
# Defined here, after the cd, so that fpga.* expands to the App files.
APP_FILES=(controllerhf.so css js c nginx.conf fpga.* index.html info py red_pitaya.bit)
WEB_FILES=(index.html css js)

# SSH key on the Red Pitaya
msg "\nIf the SSH key is not in the Red Pitaya, we upload it. \n" \
    "\nSi la llave SSH no está subida a la Red Pitaya, la subimos \n"
echo "ssh-copy-id -p ${port_number} -i ${SSH_KEY}.pub root@${RPIP}"
ssh-copy-id -p "${port_number}" -i "${SSH_KEY}.pub" "root@${RPIP}"
msg "\nIn the future, you will not need to type the root password again for remote login \n" \
    "\nEn el futuro no necesitarás tipear nuevamente la clave SSH para root. \n"

# Upload
if $webonly ; then
  ssh "${RPIP}" "${RPOPTS[@]}" "${RP_RW} ; rm -rf '${APP_DIR}'/{index.html,js,css} "
  echo -e "\n\n---------------------\n\n"
  scp "${RPSCP[@]}" -r "${WEB_FILES[@]}" "root@${RPIP}:${APP_DIR}/"
else
  ssh "${RPIP}" "${RPOPTS[@]}" "${RP_RW} ; rm -rf '${APP_DIR}' ; mkdir -p '${APP_DIR}' "
  echo -e "\n\n---------------------\n\n"
  scp "${RPSCP[@]}" -r "${APP_FILES[@]}" "root@${RPIP}:${APP_DIR}/"
  ssh "${RPIP}" "${RPOPTS[@]}" "chmod 755 '${APP_DIR}/fpga.sh'"   # Ecosystem 2.0 runs it with system()
fi

echo -e "\n\n---------------------\n\n"

msg "\nUpload finished. Just open the application in your browser: \n" \
    "\nLa aplicación fue subida exitosamente. Solo tenés que abrirla en el navegador web: \n"
echo "http://${RPIP}/${APP}"
echo -e "\n\n"
