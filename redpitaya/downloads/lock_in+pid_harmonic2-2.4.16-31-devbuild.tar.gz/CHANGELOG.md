
# Devbuild  changes


v0.3.9
- ADDED support for ecosystem 2.0 of RedPitaya

v0.4.0
- Flavour change. 
  - Removed F1, F2, F3 signals
  - Added second demodulation channel (X2, Y2)

v0.4.1
- Ecosystem 2.0 fixes, ported from rp_lock-in_pid_h v0.3.10
  - FIXED E3: parameters are sent in chunks of at most 600 B (only changed and finite values, with retries)
  - App status is probed with POST; the App is started robustly (stop + 1.5 s + start + verification)
  - ADDED "took control" detection when another client claims the board
  - ADDED save and restore of the App state in the browser
  - FIXED Config -> load; own localStorage key for this App
  - reload_fpga is disabled in Ecosystem 2.0 (nginx returns 501)
  - Cache-Control (no-cache) for index.html in nginx.conf
  - main.c (GUI_XMIN/XMAX from rp_main_params) and Makefile updated for Ecosystem 2.0 (fpga.bit.bin with bootgen, -lm -lpthread)
- Signals that are 0 in this flavour (sin_ref, cos_1f, cos_2f, cos_3f, F3o) are shown as disabled "(n/a)" options
- Restart after "took control" restores the saved values when the intruder is the same App
- ADDED cautious mode: if /get_client_id is slow or fails, /data is not requested until the board answers fast again
- First bitstream that includes X2/Y2 filtered with lpf_F1

v0.4.2
- Web interface fixes, ported from rp_lock-in_pid_h_hf v0.3.8
  - FIXED second of two quick consecutive changes being lost while a POST was in flight
  - FIXED indicators (R, X, Y, phase of both channels, scope) frozen by the edit timer after leaving a field; Escape cancels an edit
  - FIXED Enter with an out-of-range value sending two POSTs (Enter is prevented, forms use novalidate)
  - FIXED mouse wheel: no longer sends single_btn, and SHIFT + wheel uses the right sign
  - FIXED duplicated POST when using the mouse wheel on a focused field
- FIXED cautious mode entered without reason during active use: a single slow/failed /get_client_id is retried at once (cautious only if the retry is slow/fails too), a slow answer overlapping our own POST /data is not measured, and the checks to leave it are 1 s apart (was 3 s)
- FIXED endless POST loop (~15 POST/s, it crashed the nginx worker) after Config -> load of a config without some keys (e.g. of another App): missing keys keep their current value, a select without selection never gives NaN, NaN is never a pending change, and sendParams() has an anti-loop guard (no POST without changes < 200 ms after the previous one, at most 10 POST/s)

v2.4.3
- First version of the 2.x series (branch devel2.0): the same changes as lock_in+pid_harmonic v2.3.10 +
  v2.3.11 (see its CHANGELOG for the details of each one), plus the bus read fix of its v2.3.17. Everything
  that makes this App "TWO" is kept: gen_mod_h2 (cos_ref, cos_A/sin_A with gen_mod_phase_A, cos_B/sin_B with
  gen_mod_phase_B), four demodulation_line (X, Y of signal_i; X2, Y2 of signal2_i), signal2_sw, lpf_F1 for
  X2/Y2, the register map of v0.4.2 and the "(n/a)" options of the signals that are 0 in this App. The
  "v2.3.x" in the comments of the code are versions of lock_in+pid_harmonic
- CHANGED the FPGA design is built with Vivado 2020.1 (RedPitaya-FPGA project structure, project v0.94,
  model Z10 = STEMlab 125-14): lock_in+pid_harmonic2/fpga is the fpga/ of lock_in+pid_harmonic with the lock
  module of this App (lock.v, lock/gen_mod_h2.v, lock/demodulation_line.v); the Vivado 2015.2 design is kept
  untracked in lock_in+pid_harmonic2/fpga_old_2015.2
- CHANGED the oscilloscope is the RedPitaya 2.0 one: the controller unlocks the trigger (0x94) before
  every acquisition and detects its end with conf bit 4; 20-bit decimation (time range up to ~68 s);
  samples keep the 14 ADC bits (controller, c/osc, c/stream_tcp_osc_cmd, py/hugo.py)
- FIXED corrupt bus reads of live signals (in1, oscA, out1, PID...: a mix of bits of two values, 2-4 % of the
  reads in lock_in+pid_harmonic): lock.v loads sys_rdata only while sys_ren and holds it, the read-only wires
  are read from registered copies (*_rd: in1, in2, out1, out2, oscA, oscB, pidA/B in/out, ramp_A/B, cos_ref,
  cos_A, sin_A, cos_B, sin_B, error_mean, error_std, lock_feedback) and the frozen copies (*_reg) are held
  during a read; multicycle constraint on sys_rdata. config_tool.py generates the new read mux. xsim
  test/lock_bus_read_sim.sh: PASS (v0.4.2: 2000/2000 reads with sys_rdata changing < 8 ns before the PS
  sampling edge)
- FIXED streaming (c/stream_tcp_osc_cmd segfault, repeated data, first Start without data, E3, leaving the
  App while streaming, corrupt end, check_streaming), c/lock unsigned registers, /lock and /osc `?name`
  without `=`, c/ tools cross compiled by the App Makefile (`make c_tools`, c/stream_start.sh), time scale
  after Restart, a Single click made during a POST no longer lost
- FIXED streaming (testAgent 2026-10-11 00:28, also in v0.4.2): c/streaming and c/stream_tcp_osc_cmd used the
  register offsets of lock_in+pid_harmonic (stream_ip/port/rate/cmd at 0x17C..0x188); in this App they are at
  0x188..0x194 (signal2_sw, signal2_i and gen_mod_phase_B shift the map), so ctrl_B was read as the IP, the
  streaming started by itself and Stop did not stop it. The offsets are now generated by c/Makefile from c/lock.txt
  (register map of config_tool.py) into c/lock_offsets.h
- FIXED c/streaming closes the file descriptors inherited from the nginx worker (it is started from nginx with
  os.execute; the sockets stayed open in CLOSE-WAIT in c/streaming and c/stream_tcp_osc_cmd while streaming)
- REMOVED the DEBUG and RELOAD flavours (controllerhf_dbg.so, controllerhf_rld.so, src/main_*.so_.c, the
  RELOAD_DOCK marks of src/main.c, fpga.bif); only the App itself is built and packaged
- CHANGED Makefile upload targets (as lock_in+pid_harmonic v2.3.15): `make upload RPIP=...`, rw of the OS
  (2.0 and 0.9x), check_rpip, fpga.sh keeps its exec bit; settings.sh loads Vivado 2015.2 only if present

v2.4.4
- Port of the lock / web UI / controller / remote control changes of lock_in+pid_harmonic v2.3.12 to v2.3.17 (see
  its CHANGELOG for the details of each one; the "v2.3.12".."v2.3.17" in the comments of the sources are those of
  lock_in+pid_harmonic). New FPGA image. Kept from v2.4.3: everything of the TWO lock-ins (gen_mod_h2, the four
  demodulation_line, signal2_sw / signal2_i, gen_mod_phase_A / _B, X2 / Y2 with lpf_F1 and sg_amp1, the register
  map of this App, the "(n/a)" options) and the streaming offsets generated from c/lock.txt
- CHANGED the lock sequence runs entirely in the FPGA (lock_ctrl.v state machine OFF / ARMED / LOCKED): lock_control
  (0x18) is command + configuration, never rewritten by the FPGA; 0x1C is now lock_status (read only, replaces
  lock_feedback): [0] armed, [1] locked, [4:2] effective ramp / PID A / PID B enables, [15:8] lock counter. The C
  controller writes lock_control only when the user changes it and reads the status on every request; the web UI
  shows OFF / ARMED / LOCKED, Trigger Lock / Lock Now stay pressed while requested and a second click releases.
  See lock_in+pid_harmonic2/doc/lock_control.md
- CHANGED lock_ctrl.v registers its trigger inputs for timing (as lock_in+pid v2.2.6 / lock_in+pid_harmonic_hf
  v2.3.11): ramp floor trigger (counter loaded with 1 one clock later: Time trigger in the same clock as before) and
  the level / time comparisons (Level trigger 1 clock = 8 ns later). The lock-in core (demodulation, filters) is
  not changed
- CHANGED lock time trigger: 32 bits end to end (up to 2^32 - 1 ticks = 34.36 s)
- ADDED Capture Lock (each lock request captures the closing of the loop in the scope, Ext Trig = "Lock control
  trig", frozen until Auto / Single) and Fire on click. See lock_in+pid_harmonic2/doc/lock_capture.md
- FIXED "Choose from graph" with any zoom / offset / time units; a click sets only the value of the trigger type;
  the "Auto-zoom" option was removed
- ADDED Time trigger / Level trigger fields with units (16.58 ms, 20 s, 0.1 V, 120 mV...); an emptied number field
  is never sent as 0
- FIXED Config -> load applies the scope window in the right units (seen by testAgent on v2.4.3, 1 of 2 loads with
  the page in us) and does not send forcex_flag / time_units / time_range / gui_x* nor the read-only params; the full
  config is sent in chunks with the window applied from the answer of the last one
- FIXED every POST reset the scope (a Single waiting for its trigger was disarmed); AUTO after a lock capture; aborted
  auto-set; zoom-out right after a change of time units
- CHANGED PID integrator divider label "6 us" -> "65 us"; descriptions of X / Y (X, Y: cos_A / sin_A of signal_i;
  X2, Y2: cos_B / sin_B of signal2_i); pidA_sw / pidB_sw 4 bits (0..15, the width of the selector)
- ADDED HTTP remote control on Ecosystem 2.0: /osc writes TrgUnlock (0x94) and c/osc addresses registers by index;
  register ranges in config_tool.py / c/lock.txt; resources/remote_control/http_version/control_finn.py of
  lock_in+pid_harmonic v2.3.17 (scope_stop() / scope_auto(), minimal POST /data in one packet, WebScopeNotStopped,
  host resolved once) adapted to the two lock-ins: reg_labels from the selectors of this App (cos_A..sin_B, X2o,
  Y2o, signal2_i, signal2_sw), set_phase(val, line='A'|'B') (gen_mod_phase_A / _B), set_signal(sw, line),
  set_gain(line, amp) (sg_amp0 / sg_amp1), set_lpf() / get_lpf() with lines 'A' (lpf_F0) and 'B' (lpf_F1),
  get_XY(F=True) returns X, Y, X2, Y2; example_usage.py with both lock-ins and the ramp of
  test_files/lock_in+pid_harmonic2__lock_mode.json
- ADDED py/lock_from_registers.py (arm / lock now / release / status writing only FPGA registers); py/hugo.py
  lock_status and osc.acq_done(); control_hugo.py launch_lock() / lock_now() / release_lock() / lock_status()
- Tests (lock_in+pid_harmonic2/test/): xsim lock_ctrl_sim.sh and lock_bus_read_sim.sh; node lock_ctrl_ui_sim.js,
  lock_capture_ui_sim.js, trig_input_units_sim.js, config_load_window_sim.js, trig_from_graph_sim.js;
  auto_set_c_sim/run.sh (controller C on the PC)

Documentation (after v2.4.4, no change of code)
- ADDED doc/App.md, doc/Usage.md, doc/Structure.md (Mermaid diagrams), doc/FPGA.md (the 102 registers of this App,
  checked against lock.v), doc/Remote.md, doc/Devel.md, based on the documentation of lock_in+pid_harmonic 2.3.17
  and adapted to the two lock-ins; screenshots in doc/.Usage/ and doc/.Remote/
- CHANGED doc/README.md is now an index (its old register table, of an older lock.txt, is replaced by doc/FPGA.md);
  README.md rewritten (summary of 2.4.x, documentation table, installation, building, license); the detailed
  requirements moved to doc/Devel.md and the version history stays in this file

v2.4.5
- Port of the minor fixes of lock_in+pid_harmonic v2.3.18 (no FPGA change: the image is the one of v2.4.4, only
  comments of lock.v changed; the "v2.3.18" in the comments of the sources is that of lock_in+pid_harmonic)
- FIXED lock trigger registers written from Python (py/lock_from_registers.py --time/--level/--sw, control_finn.py):
  lock_trig_val / lock_trig_time / lock_trig_sw follow the rule of lock_control: the C writes each one only when its
  parameter changes and copies a value written from outside to the parameter (the page shows it and keeps it; before,
  it was not shown and the page value was written back at the next change of any lock parameter)
- FIXED Config -> load sent read-only parameters of the server (meas_*, lock_X/Y/X2/Y2, lock_lock_status,
  lock_lock_control, trig_delay, ...): skipped (server_ro_keys, the read-only list of src/main.c of this App)
- FIXED Single mode made no request at all after its acquisition (a bazaar?stop, e.g. after Prepare Streaming, or
  another client was not noticed, the lock label was not refreshed): 1 s polling in Single; an AGAIN answer starts
  the fast polling only while a Single click waits for its acquisition
- FIXED console "Capture Lock: ended by , scope settings restored" (the reason is given); mouse wheel on Ramp period /
  limits, PID, phases A/B, modulation and lock trigger fields updates the text below them; X+ of the plot range up
  to 68.72 s (it stopped at 10 s)
- FIXED py/lock_from_registers.py: --time clamped to 0..2^32-1 ticks with a message (40s gave OverflowError), ns/us
  accepted, --sw 0..15, docstring (--sw is "Signal for trigger": 0 error, 1 Xo, 2 Yo, 3 X2o, 4 Y2o, 5 F3o, 6-8 are 0)
- FIXED example_usage.py: the Lock cell restores the two lock-ins and PID A of lock_in+pid_harmonic2__lock_mode.json
  (phase A 0, phase B 630; RESTORE_LOCK_MODE = False prints a warning instead), and "save data" ends with
  rp.scope_auto() (the script left the scope of the page in Single)
- FIXED upload_app.sh: rw script of the OS as the Makefile (/opt/redpitaya/sbin/rw or /boot/sbin/rw), -w removed
  {index.html,js.css} (js,css), fpga.sh exec bit
- CHANGED c/streaming.c: its "Finishing streaming" message no longer ends with ": Success" (perror with errno 0);
  c/stream_tcp_osc_cmd runs with nice -10 and locked memory (fewer lost samples at decimation 128 with activity on
  the board, e.g. an ssh login; STREAM_NICE=<n> changes it)
- CHANGED AUTO: minimum window 1 us (was 100 ns: with noise only it gave 0...139 ns)
- CHANGED texts: "Signal for trigger" 6-8 "0 (sqXo)"..; ctrl_B = pidB_out + ramp_B (lock.v, fpga_lock.h, main.c,
  config_tool.py); 20-bit decimation in src/fpga.h and fpga/README.md; resources/README.md (read with name= or name);
  doc/lock_control.md and doc/Remote.md (trigger registers written from outside)
- Tests: test/minor_ui_sim.js (new), lock_capture_ui_sim.js part 7 (Single polling), config_load_window_sim.js
  (no read-only key sent), auto_set_c_sim parts 4 and 5

v2.4.6
- FPGA timing (port of lock_in+pid_harmonic v2.3.19, the user allowed adding latency): WNS -9.618 -> -1.281 ns,
  TNS -9950 -> -510 ns, 4927 -> 996 failing endpoints (reset recovery -1.608 -> +0.414 ns). Pipeline registers in the
  long combinational chains of the loop; same behaviour except for the latencies (bit by bit in simulation against
  v2.4.5). Details and latency of each signal: lock_in+pid_harmonic2/doc/lock_latency.md
- CHANGED (FPGA, added latency, 8 ns per clock): generator outputs +1 (gen_mod_h2 wrapper with registered outputs);
  Xo, Yo, X2o, Y2o +2 (demodulation_line: register after the first LPF stage and output register); bus X_28..Y2_28
  +1; PID outputs +1; out1/out2 +1. LOCK MODE loop +32 ns
- CHANGED (FPGA): the references reach the two lock-ins 1 clock later than the outputs, so the phase measured
  through DAC -> system -> ADC does not change (lock_in+pid_harmonic 2.3.19 does not have this compensation)
- CHANGED (FPGA, same values): shift_sat14 in demodulation_line, sat14 without barrel shifter, PID integrator with
  the ISR shift in parallel, sum_div of the second LPF stage in a register; sg_amp1 connected as {1'b0, sg_amp1}
- CHANGED page title (h2.page-title) and <title> get the version of info/info.json at build time (Makefile)
- ADDED test/lock_latency_sim.sh + test/lock_latency_tb.sv (xsim, 406 checks against v2.4.5)

v2.4.7
- Port of lock_in+pid_harmonic v2.3.21 (Reset zoom), v2.3.22 (mouse wheel) and v2.3.23 (slow scans, FPGA lock_ctrl.v);
  see its CHANGELOG for the details and the board tests. New FPGA image. "v2.3.2x" in the comments are those of
  lock_in+pid_harmonic. The two lock-ins, their register map and the lock control are not changed.
- ADDED Reset zoom: X from t = 0 to one period of the ramp (Ext Trig = Scan floor / Scan ceil: sawtooth
  (high-low+1)*(step+1), triangle 2*(high-low)*(step+1) ticks), one period of the modulation shared by both lock-ins
  (harmonic mod.: 2520*(hp+1) ticks, gen_mod_h2.v) or one whole memory at the current Dec (other Ext Trig); periods
  >= 1.5 s: 0.98 x the period (at least 50 ms before the next trigger). Y to -1..1 V (raw mode -8192..8192). During a
  lock capture it first ends it (as AUTO); the Raw Mode button rescales Y
- CHANGED the "Square mod." Ext Trig is no longer in the trigger menu (not implemented in this App: always 0 in the
  FPGA); also removed from resources/config_tool.py, labelled "0 (Square mod.)" in control_finn.py
- ADDED mouse wheel on the scope: no key zooms both axes, SHIFT only time (cursor ew-resize), ALT only the Y axes
  (cursor ns-resize, no POST); X window 20 ns .. 68.7 s; local zoom during a lock capture; xmin/xmax sent without
  rounding to 2 decimals (a fast zoom from s to ms sent 0/0)
- FIXED slow scans (windows >= 1.5 s): new long-acquisition reader in src/worker.c (rp_osc_long_rd_*: never a sample
  of an older lap of the scope memory or from before the history, adc_we_cnt register 0x2C, OK only when complete,
  ends at the window of the user); Capture Lock holds the lock request until the scope has enabled its trigger
  (lock_request_* in src/lock.c, the POST answers at once); read-only params scope_gen, scope_acq_state,
  scope_acq_gen, sig_gen (PARAMS_NUM 211 -> 215); page: capture recognised by sig_gen, partial traces drawn,
  banners, real "LOCKED but not captured"; Reset zoom clears stale traces
- FIXED (FPGA, lock_ctrl.v): the time trigger counter is valid (cnt_ok) only from a floor of a ramp that has been
  running since then (new input ramp_run = ramp_enable & ~ramp_reset) and it saturates instead of wrapping every
  34.4 s: a time (or level+time) request armed after a stop fires at the next floor + time, never mid-scan. Adapted
  to the registered trigger inputs of this App (v2.4.4): cnt_ok is set with ramp_trigger_r and delayed once for
  level+time; with the ramp running the lock fires in the same clock as before. time_eq is built from lock_trig_time-1
  and two flags in registers (the saturation inside cnt_next would lengthen the comparison path, -0.26 ns in
  lock_in+pid 2.2.9); same value every clock (lock_ctrl_tb.v checks it against cnt_next == lock_trig_time)
- example_usage.py: note about time / timeout for slow ramps
- Tests: new test/reset_zoom_sim.js (29), test/plot_wheel_sim.js (59), test/ramp_mod_period_sim.sh (ramps and
  gen_mod_h2 2520*(hp+1), 10); lock_capture_ui_sim.js section 8 (79), auto_set_c_sim sections 6-9 (44),
  lock_ctrl_tb.v cases 16-19 and the time_eq monitor (46)

v2.4.8
- Port of lock_in+pid_harmonic v2.3.24 (web page only: no FPGA, no controller change). X|Y is lock-in A (Xo, Yo); X2o/Y2o of lock-in B are not in the fixed presets (the `usr` dialog offers every signal of the selects, X2o/Y2o included).
- ADDED presets of the scope signals: six small buttons below Ext Trig (two rows of three, 42x20 px, 10 px bold):
  blue in1|in2, in1|ctrl (ctrl_A), X|Y (Xo, Yo of lock-in A); green in1|err (error), ctrl|err (ctrl_A, error) and usr.
  A click sets OscA/OscB (mux 1, 2, 3, 4, 17, 18) as the two selects do: one POST with only lock_oscA_sw / lock_oscB_sw
  (plus single_btn/xmin/xmax unchanged); zoom, trigger and Capture Lock untouched; tooltips name the two signals
- ADDED usr preset: double click (or a click while not configured, dashed border) opens a dialog with all the
  signals of the selects (default the first time: PID A out | error); Accept saves it in localStorage
  (oscUsrPreset_lock_in+pid_harmonic2) and in the configs (Config save / download json, ui.ui_osc_usr_a/b, never sent to the
  server); Config load of a config with it takes it, older configs keep the current pair
- CHANGED picking an Ext Trig other than the current one and not None sets the Trigger panel to Source = External,
  Mode = Normal in the same POST (from Single the page polls again); None changes nothing else; Config load, the end
  of a Capture Lock, Reset zoom and AUTO do not apply it; during a Capture Lock it ends it, then one POST
- Tests: new test/osc_presets_sim.js (37; the page of 2.4.7 fails 32); config_load_window_sim.js: stub of
  oscUsrConfigLoad()

v2.4.9
- Port of lock_in+pid_harmonic v2.3.26 (no FPGA change)
- CHANGED (controller, src/worker.c) Auto waits for the trigger like Normal (Ext Trig with Source External, or the level
  of a channel) and forces the acquisition only if no trigger came within max(0.25 s, 1.1 x window + 50 ms, 1.1 x period
  of the Ext Trig + 50 ms), at most 80 s; the period is known for Scan floor / ceil with the scan running (Scan enable,
  no reset, lock_status bit 4) and for harmonic mod. (2520 x (hp+1) cycles). Up to 2.4.8 Auto triggered at once (trig_imm): t = 0 at any phase of
  the scan even with Ext Trig = Scan floor (testAgent 2026-10-19, sq). Normal, Single, Capture Lock, AUTO, the Auto
  window (from the trigger) and the long acquisitions unchanged; a 30 s scan in Auto acquires every scan from its floor
- CHANGED the trigger Level field / line / slider are enabled in Auto too; the "Choose from graph" warning accepts Auto
- CHANGED "Don't turn on PIDs and Ramp on config loading" (#load_config_block_start) is unchecked by default (it was
  checked): Config load / Load file and the restore after a start / Restart set the ramp enable, Scan enable
  (lock_ramp_enable) and the PID A/B enables as saved; checked, they are set to 0 as before. Lock requests (lock_now,
  launch_lock_trig) and stream_cmd are never loaded (state_transient_zero)
- CHANGED the option is not saved anywhere: every page load starts unchecked (autocomplete="off", variable synced
  from the checkbox)
- CHANGED <title> / page title of the source index.html (said v2.4.7)
- Tests: new test/config_load_block_sim.js (10; the page of 2.4.8 fails 6); test/auto_set_c_sim/harness.c section 10
  (SIM_AUTO=1): Auto + Scan floor only floors, scan stopped forced every ~0.40 s, 3 s scan in 0..0.1 s only floors, Normal
  without trigger nothing (the src of 2.4.8 fails 10.1-10.3); 6.1 runs 9 s, section 8 waits 0.6 s

v2.4.10
- Port of lock_in+pid_harmonic 2.3.27 (web page only, no FPGA / C change). Requested by the user (2026-10-20): the App
opened with the parameters of a previous session; the user wants to choose.
- CHANGED: **Lock Control** panel moved right below **Outputs** in the left column (Oscilloscope, Outputs, Lock Control, Lock-in modules, Ramp Controller, PIDs modules, Streaming).
- CHANGED: the state that the page saves automatically (`saveState()`, every ~2 s and after each POST) is now also kept in
  **localStorage** (`lockin_last_state_lock_in+pid_harmonic2`, shared by the tabs, survives closing the browser): the **last config**.
  The tab state (`sessionStorage`, used by *Restart*) is kept as before.
- ADDED (Config dialog) checkbox **Load last config on init** (`#load_last_on_init`), **checked by default**, saved in
  localStorage (`lockin_load_last_on_init_lock_in+pid_harmonic2`). When the page starts the App (main menu, new tab, F5): checked, the
  last config is restored; unchecked, only `def_params` are sent (defaults of `src/main.c`). Ramp / PIDs of a restored
  config follow *Don't turn on PIDs and Ramp on config loading*; lock requests are never restored.
- ADDED (Config dialog) buttons **Load last config** and **Reset to defaults**: they close the dialog and restart the App
  (reload; stopped and started as when it is opened, FPGA reloaded) with the last config / with the defaults, whatever
  the checkbox says. Reset to defaults = a fresh App (no table of defaults in the page), lock open, no lock request.
- ADDED hold (`lockin_last_hold_lock_in+pid_harmonic2`): opened with the defaults, the last config is kept until the user changes a
  parameter (time window / Y axis alone do not count), so *Load last config* brings it back.
- *Restart* (took control, error dialogs) and the automatic restarts still restore the tab state; an App already running
  when the page opens keeps its state (stopped and started for Load last config / Reset to defaults).
- Tests: new `test/last_config_sim.js` (35 checks; the page of 2.4.9 fails). The other node tests unchanged and passing.

v2.4.11 - 2026-10-20 - Quick trigger buttons time / level / time+level in Lock Control; fixed lost time/level and re-lock with a POST in flight (as lock_in+pid_harmonic 2.3.28)
- Port of lock_in+pid_harmonic 2.3.28 (web page only, no FPGA / C change; same code, the lock trigger options and
the Choose from graph / Fire on click code of this App are the same as there). Requested by the user (2026-10-20).
- ADDED: **Lock Control**: three small buttons stacked between **Trigger Lock** and **Lock Now**: **time** (orange),
  **level** (blue), **time+level** (purple). A click on one of them sets the lock trigger type (Time trigger / Level
  Trigger / Level+time Trigger) and waits for a click on the graph, as *Choose from graph* (the *config* section is not
  opened): the button stays filled, the cursor over the scope is a crosshair and a short message
  (`#lock_quick_trig_msg`) is drawn over the rows below (state label, checkboxes) without moving the panel. The click
  on the graph sets the type and the time (from the scan floor) and / or the level and fires **Trigger Lock** at once
  (whatever *Fire on click* says), with **Capture Lock** if it is checked. Nothing is sent while waiting (an ARMED /
  LOCKED lock is kept until the click, then released and armed again). A 2nd click on the same button, Esc or
  *Choose from graph* cancel; another of the three buttons changes the type.
- CHANGED: layout of that row: *Trigger Lock*, the column of the three buttons and *Lock Now* are one centered flex row
  (column as tall as the big buttons, which are a bit larger: 16 px font, 60 px high); a container query makes all of
  them a bit smaller in a narrow left column (row < 235 px, e.g. 1366 px wide windows).
- FIXED: a click with *Choose from graph* + *Fire on click* while another POST was in flight lost the new time / level
  (`loadParams()`, `trigger_just_set`, wrote them as already sent; Trigger Lock fired with the old values). Now only
  the values already sent are protected; pending ones are sent after that POST.
- FIXED: with the lock LOCKED and a POST in flight at the click on the graph, neither the release nor the new request
  was sent (the send queued during a POST runs 100 ms after its answer and `lockWhenIdle()` did not wait for it). Now
  it is kept in `send_que_timer` and `lockWhenIdle()` waits for it: the release goes first, then the request.
- Tests: new `test/lock_quick_trig_sim.js` (57 checks, harness of `lock_capture_ui_sim.js`; the page of 2.4.10 fails 51).
  The other node tests unchanged and passing.

v2.4.12 - 2026-10-24 - Raw Mode: scope trigger level in ADC counts (C controller + web page, no FPGA change; as lock_in+pid_harmonic 2.3.29)

Port of lock_in+pid_harmonic 2.3.29 (same code in this App). Bug found in `rp_dummy2` (which inherited this code),
present in all earlier versions: with **Raw Mode** on, the *Level* of the scope trigger did not work.
- FIXED (C controller): in Raw Mode the page sends the level in ADC counts, but the controller passed it to
  `osc_fpga_update_params()`, which converts **volts** to counts: 100 counts were taken as 100 V and the threshold
  saturated (8191 minus the calibration offset; −3000 even wrapped to a positive threshold), so Normal / Single never
  triggered for a level other than 0. Now `rp_osc_trig_level_v()` (`src/worker.c`) turns the counts into the voltage
  that `osc_fpga_cnv_v_to_cnt()` maps back to exactly those counts (`osc_fpga_cnv_cnt_to_trig_v()`, `src/fpga.c`, with
  the calibration offset of the input selected by OscA / OscB and the user offset). A level beyond 8191 − calibration
  offset saturates there, as in volts mode.
- FIXED (C controller): AUTO in Raw Mode: the level of its search left the calibration offset out, its result (counts)
  was then applied as volts, and its Y range (counts) was scaled and clipped to ±1000 (`min_y` / `max_y` (`_norm`)
  limits, now ±20000; not scaled in Raw Mode). Volts mode unchanged.
- FIXED (web page): *Level* field, slider (and its drag) and trigger line in counts in Raw Mode (whole counts,
  −8192 … 8191; they used the volts scale and ±1), in V otherwise (± full scale); out-of-range values limited before
  sending; unit `counts` / `V` next to the field. The **Raw Mode** button converts the level (counts = V × 8192 / full
  scale at gain 1). *Config → load* of a config with the other Raw Mode sets Y to the Reset zoom range of its mode
  once (its level is not converted). The page opened in Raw Mode starts with Y ±8192 (it was ±1 count).
- Tests: new `test/raw_trigger_sim.js` (45 checks; the page of 2.4.11 fails 31) and `test/trig_level_test.c` (real
  `src/fpga.c`); `test/auto_set_c_sim` section 11 (thresholds written by the real controller in Raw Mode, AUTO in Raw
  Mode; the sources of 2.4.11 fail 6 of its 10 checks); `lock_capture_ui_sim.js`, `lock_ctrl_ui_sim.js`,
  `osc_presets_sim.js` load the new `[RAW TRIGGER]` block.

v2.4.13 - 2026-10-24 - AUTO trigger level at the middle of the signal with a calibration offset or a full scale other than 1 V; Raw Mode half counts (C controller; page: version and comments only; no FPGA change; as lock_in+pid_harmonic 2.3.30)

Port of lock_in+pid_harmonic 2.3.30 (same code in this App). Issues of the AUTO found in the review of v2.4.12 (the half
count was seen on RP2 by testAgent, 2026-10-24 21:44; the other two do not show on RP1 / RP2).

- FIXED (C controller): **AUTO in volts with a calibration offset** (`fe_chX_dc_offs` of the input, from the EEPROM;
  RP2's are 0): the AUTO measures the signal with samples corrected by the offset, but the threshold registers compare
  raw samples. The threshold of its period search added the offset a second time (one offset **above** the middle),
  and the level it left had no offset at all (threshold and page line one offset **below** the middle of the trace).
  Now both are the middle of the signal in raw counts, and the level is the normalized voltage that the acquisition
  path turns into that threshold (`osc_fpga_cnv_cnt_to_trig_v()` with the calibration and user offsets): the *Level*
  shown by the page is the middle of the trace. Its period search compares raw samples with raw limits (a signal
  smaller than the offset gave no period) and its Y range no longer mixes raw and corrected counts.
- FIXED (C controller): **AUTO in volts with a normalized full scale other than 1 V** (`fe_ch1_fs_g_hi` of the EEPROM;
  RP1 / RP2 have exactly 1 V, a typical factory calibration ~1.07 V): the level and the Y range were stored as
  counts / 8192, but a normalized value is counts × full scale / 8192 (the acquisition converts the level with that
  full scale, the page multiplies by chX full scale / that full scale): both were scaled by 1 / full scale (~7 %).
- With offsets 0 and a full scale of 1 V (RP1 / RP2) the volts AUTO gives the same result as before.
- FIXED (C controller): **Raw Mode, half counts**: the AUTO left a level of half a count (e.g. −2.5) that the page
  showed as −2 (`Math.round`) while the controller wrote −3 (`roundf`). Now the AUTO gives a whole count rounded as the
  page, and `osc_fpga_cnv_cnt_to_trig_v()` rounds a level with a fraction (e.g. from a remote client) the same way
  (`floor(x + 0.5)`): the Level field and the threshold register always agree.
- Tests: `test/auto_set_c_sim` section 11, new checks 11.10-11.16 (calibration offset 585 and normalized full scale
  0.6543 V of the harness: volts AUTO threshold of the search and of the acquisitions that follow at the middle, level
  shown by the page = middle of the trace, Y range in V, Raw AUTO with a middle of −2.5 → −2 in level and register,
  half counts from a remote client; with the sources of v2.4.12, 6 fail: 11.13 already passed);
  `test/trig_level_test.c`: levels with a fraction (±0.25, ±0.5, ±0.75) give the count the page shows (with the
  `src/fpga.c` of v2.4.12, 64004 fail); `test/raw_trigger_sim.js`: section 9 (page and controller round half counts
  the same way) and code checks 8.4, 8.6-8.9 (53 checks; with the sources of v2.4.12, 5 fail).

v2.4.16 - 2026-11-26 - Calibration of the EEPROM in the universal format (5 / 6, Gen2), ADC offset subtracted, calibration in the display (Raw Mode off), Raw Mode = plain integers (port of lock_in+pid_harmonic 2.3.33 = lock_in+pid 2.2.17; C controller + web page, FPGA unchanged)

Port of `rp_lock-in_pid_h` **v2.3.33** (`a502b55`), which ports the calibration work of `rp_lock-in_pid` **v2.2.17**
(builds 33 … 36; see the CHANGELOG of lock_in+pid for the history of each build). The new code is marked `v2.4.16` (in
`index.html` some comments keep `lock_in+pid 2.2.17` / `build 35` / `build 36` as the reference). Bug reported on a
**STEMlab 125-14 Pro v2.0 (Gen2)**: IN1 at a constant > 30 V and IN2 at ~0 V with the inputs open
(`reportes/gen2_resultados.md`, Apps folder): the calibration is stored in the universal format 6 and the App read it with
the layout of `apps-free/scope` (2013).

**EEPROM:**
- FIXED **`src/calib.c` / `src/calib.h` read the format of the EEPROM** (identical to lock_in+pid 2.2.17 and
  lock_in+pid_harmonic 2.3.33, md5 `797d4a32…` / `045a9bde…`; the old copies were the common `72a4df3b…` too): **5 / 6
  (universal)**: header + `{u16 id; i32 value}` items; **1 or no header**: the old layout, with the **LV** offset at
  `0x34` / `0x38` when the magic is valid. User zone; if not valid the factory zone (`0x1c00`); else **nominal values**
  (1 V / 20 V, offsets 0, DAC 1 V, 2 V on Gen2). Sanity: LV 0.5 … 2 V, HV 10 … 40 V, DAC 0.5 … 3 V, offsets within
  ±1000 counts. `hw_rev` `…_v2.0` = Gen2 (DAC chip full scale 2 V). One line `Calibration: …` in the log of the App.
- FIXED **sign of the ADC offset** (subtracted, as the official library; the App added it) and **offset of the LV range**
  (the HV offset was used in both ranges).
- CHANGED nominal values: 1 V / 20 V, offsets 0 (they were the 0.6543 V / 14.56 V / offset 585 of apps-free 0.9x).
- ADDED read-only parameter **`calib_status`** (0 user zone, 1 factory zone, 2 nominal) and a warning next to the title
  of the page when it is not 0 (`calibWarn()`).

**Display (final rule of the user, build 35 of lock_in+pid):** a value $n$ is shown as $V = (n + c)\,k/8192$, the same
rules in the controller (new `src/sig_scale.h`: scope traces, Measure, scope trigger, `scale_ch1` / `scale_ch2`) and in
the page (block `[CALIB DISPLAY]`: labels, lock-in displays, voltages typed with units). The FPGA gets the same integers
as before. **Raw Mode off:**

| Signal | volts of 8192 counts ($k$) | correction $c$ |
|---|---|---|
| in1, in2 | that input, its range (*Gain settings* Channel 1 = IN1, Channel 2 = IN2) × probe | its ADC offset |
| in1-in2 (level trigger 14) | mean of IN1 / IN2 of the range in use (× probe); different ranges / probes: mean of the LV ones | 0 |
| lock-in displays X, Y, R (lock-in A) | input calibration of *Lock-in input A* (`lock_signal_sw`): in1 → IN1, in2 → IN2, in1-in2 → mean; cos_ref, sin_ref, cos_1f, aux_A, Ramp A → nominal | 0 |
| lock-in displays X2, Y2, R2 (lock-in B, only in this App) | the same with *Lock-in input B* (`lock_signal2_sw`) | 0 |
| ctrl_A, ctrl_B | DAC of the output they go to (not routed: the DAC of another signal of their chain, else OUT1 / OUT2) | −DAC offset if routed directly |
| out1, out2 (scope selector 23 / 24: the integer of each DAC) | DAC of that output | −its DAC offset |
| everything else: error, Xo, Yo, X2o, Y2o, signal_i, signal2_i traces, PID inputs (also in1 / in2 / in1-in2 as PID input) and set points, Ramp A / B, PID A / B out, aux_A / B, references cos_ref, cos_A, sin_A, cos_B, sin_B (routed or not) | **nominal** 1 V | 0 |

- So ctrl = ramp + PID out holds in counts, not exactly in volts (ctrl_A with the DAC, Ramp A and PID A out nominal).
- **PID inputs in1 / in2 / in1-in2** (`lock_pidA_sw` / `lock_pidB_sw` 9 / 10 / 8): nominal, as lock_in+pid and
  lock_in+pid_harmonic (lock_in+pid_plus gives them the input calibration). Pending decision of the user: it is a
  **one-line switch**, `RP_SIG_PID_IN_CALIB` in `src/sig_scale.h` and `calib_pid_in_calib` in `[CALIB DISPLAY]` (change
  both; `test/calib_display_sim.js` checks that they agree and tests the other position too).
- CHANGED scope traces / Measure / trigger: each scope channel takes the scale of the signal it shows (it was the IN1 /
  IN2 full scale of channel A / B for any signal). A change of `lock_out1_sw` / `lock_out2_sw` / `lock_pidA_sw` /
  `lock_pidB_sw` updates the scope worker.
- CHANGED labels of the page (Ramp lims, mVpp / mVdc, *freq* tab, PID set points (they divided by 8191), $V_\mathrm{trg}$,
  lock-in displays (1 V = 8191 before)), refreshed when Raw Mode / calibration / ranges / routing / lock-in inputs change.
- **Units rule:** a value typed **with units** (`V`, `mV`; *Level trigger*, *Amp. p-p*, *Offset*, click on the plot for
  the level trigger) is converted with the scale of its signal, $n = \mathrm{round}(V\cdot 8192/k - c)$; a **bare
  number** is the integer as it is. Raw Mode on and off.
- ADDED 12 read-only params `calib_in1_lv` … `calib_out2_offs` (not sent, not saved in configs). `PARAMS_NUM` 228.
- **Raw Mode on = the plain integers of the FPGA everywhere**: FIXED the Measure table added the calibration offset
  (`rp_osc_meas_convert()`); labels in `counts`; lock-in displays X, Y, R, X2, Y2, R2 are the 28-bit registers (they
  were / 2048); the titles of the 2nd lock-in also switch to `X2 [int]` … `ϕ2 [deg]` (they stayed `X2` … with the
  integers); Y range of the plot in `counts` (it said "16384 V").
- FIXED "0.5 V" in the PID set point code path (`parseInt` gave 0).

**Fixes of the board test of lock_in+pid 2.2.17-34 (build 36):**
- FIXED **titles of the lock-in displays after Raw Mode on → off** (they stayed "X [int]" …: `last_disp_units` read the
  non-existent `#btn_disp_units`; now it is the Raw Mode of the last update). The same code was in this App.
- FIXED **scope *Level* field with unrounded volts** (`0,249999689324`): rounded to `trigLevelDecimals()` (display
  only; the parameter keeps its value).
- FIXED "3124 countspp" → "3124 counts pp" / "counts dc" (`calibSfx()`).

**Not changed:** `py/` and `resources/` (8192 counts = 1 V); the AWG of `generate.c` is not used by the App; FPGA
(`fpga.bit.bin` `27a038e7…`, `red_pitaya.bit` `701094a8…`).

- Tests: new `test/calib_test.c` (38/38, identical to lock_in+pid), `test/calib_display_sim.js` (50 checks, adapted to
  this App: displays of lock-in A / B, scope references cos_A … sin_B, PID inputs without Ramp A (7 = signal2_i), 800
  random cases page = controller through the new `test/sig_scale_dump.c`, in both positions of the switch of the PID
  inputs), `test/disp_labels_sim.js` (7/7, X … ϕ2; v2.4.15 fails 5); `test/raw_trigger_sim.js` 58/58 (rounding
  checks); `auto_set_c_sim` with a fake EEPROM image of the old defaults (`fake_fopen()`) and 11.17-11.22;
  `trig_level_test` ALL PASS; the other node sims pass.
- `controllerhf.so` rebuilt; FPGA unchanged. Not tested on a board.

v2.4.16, 2nd commit - 2026-11-26 - bug 11: no exponential notation in the lock-in displays (web page only)

- FIXED **bug 11** (found by testAgent in the board test of `lock_in+pid_harmonic` 2.3.33-75): with *Lock-in input*
  in2 and *Channel 2* HV the display F2 = 97 counts read `1.2e+2 uV`. `display_update()` gives `format_oom()` the
  number of digits of the integer of the FPGA (`String(lock_F2).length`) as the precision of `toPrecision()`; with the
  scale of HV ($\times 20$), of a probe ($\times 10$) or after the change of prefix, the value has more digits in its
  integer part than that and `toPrecision()` switched to exponential notation (also at a decade: 99.96 with precision 2
  gave `1.0e+2`). `format_oom()` now uses at least the digits of the integer part (115.7 µV → `116 uV`), also when the
  rounding reaches the next decade (99.96 → `100`) or 1000 (next prefix: 999.96 µV → `1.00 mV`), shows `---` for a value
  that is not finite and keeps the prefixes in p … T. The same function serves every lock-in display of the page
  (X, Y, R, ϕ of lock-in A and X2, Y2, R2, ϕ2 of lock-in B) and the times of the lock capture: no label uses exponential notation any more. Web page only.
- Tests: `disp_labels_sim` 10/10 (new 11.1-11.3: the real `format_oom()` of the page, the case of the board, a sweep of 331 integers × 2 signs × 12 scales through the real `display_update()`; the page before this fix fails 3 of them); the other tests unchanged and passing.
- `controllerhf.so` rebuilt; FPGA unchanged. Package `lock_in+pid_harmonic2-2.4.16-31-devbuild`. Not tested on a board.

v2.4.15 - 2026-11-13 - Force X of a retried POST: the 2nd click of Reset Zoom is no longer lost (web page only, no FPGA / C change; from lock_in+pid_plus 2.2.1)

Port of the fix of `rp_lock-in_pid_plus` v2.2.1 (`a8d4b0b`; see its CHANGELOG). Only `index.html` and
`test/forcex_race_sim.js`; FPGA and C sources unchanged (`controllerhf.so` only rebuilt). In `index.html` the new code
is marked `v2.4.15 (plus 2.2.1)`. Bug found by testAgent in lock_in+pid 2.2.16 (Force X 19 of 21) and lock_in+pid_harmonic2
2.4.14 (27 of 28): `reportes/lock-in_pid/2026-11-13_1806_v2216.md`.
- **Fixed — the 2nd click of Reset Zoom lost when the POST of the 1st one is retried.** nginx hangs ~2 s every
  ~3 min; if the POST of the 1st click (0 … T) falls in a hang it gets no answer in `post_chunk_timeout` (2 s) and is
  sent again with the same body, while the 2nd click (0 … T/2) waits. The answer of the retry (`forcex_flag` 1 with
  0 … T) put the axis back to 0 … T and the waiting POST sent 0 … T again. Now (`[FORCEX]` block) the answer of a POST
  during which the page set the X window itself (`xwin_gen` moved) does not set the window: `forceXStaleKeep()` keeps
  the window of the page in the units of the answer and `xwin_resend` makes the next POST send it; no forceX of a GET
  /data is applied while a window of the page is not sent yet (`xwin_pending`), and a forceX of a GET that is not
  applied does not change the time units of the page (`forceXUnitsKeep()`). (First round; superseded by the second round below:) the retry kept the same body on purpose
  (the timed-out POST may have been served in other units).
- **Fixed — a parameter changed back to its previous value during a POST in flight was lost** (a GET answered meanwhile
  carried the old server value). `post_sent`: for the keys of the POST in flight a GET answer does not replace
  `params.local` and `unsent_base` keeps the sent value.
- Tests: `test/forcex_race_sim.js` case 5 (timeout + retry + 2nd click during the wait, 12 runs, kp changed during the
  wait): 12/12; with the previous `index.html` (`--old`) 5c and 5e fail.

#### Second round (same tag, moved): the timed-out POST that the server did serve

Board test of testAgent with the first round (`reportes/lock-in_pid/2026-11-13_1848_forcex_retry.md`): it worked when the
timed-out POST never reached the server (32/32), but failed always when it did (hook `__serve = true`, the realistic case:
nginx hangs ~2 s and then serves it; pid 0/6, h2 0/2, also _h and sq). `src/main.c` reads `xmin`/`xmax` in its current
units (`time_units` is read-only) and protects a forced window only for `FORCEX_STALE_MS` (1.5 s): the retry with the same
body (0 … 9984 in µs) was read in ms and sent the server to s, and the window the page sent next was ignored (while
`forcex_state` is 1 a window more than 33× away from the forced one is not taken). No C change; in `index.html`
(marked `v2.4.15 (plus 2.2.1)`):
- `postParamsChunks(.., post_info)`: the retry of a timed-out chunk goes **without `xmin`/`xmax`** (all the other values
  are absolute; a chunk left empty carries `auto_flag` 0, a no-op), and `post_info.window_unsure` makes `sendParams()`
  treat the answer as stale: the window of the page is sent again in the units of that answer (the units of the server).
- Every POST that sends a window checks that the answer has it (`xWindowTaken()`: same window in seconds, tolerance
  $10^{-4}$ of its width). An answer with `forcex_flag` 1 and another window (the server kept its forced one) is also
  stale: the page keeps its window and sends it again after `forcex_hold_ms` = 1.7 s (> `FORCEX_STALE_MS`), up to 3
  times in a row (then it takes the window of the server). While that resend waits, POSTs for other changes go without
  `xmin`/`xmax` and their answers do not set the window either. AUTO cancels a pending resend.
- GET /data: a GET whose forceX is not applied never changes the time units of the page (also with `forcex_flag` 0:
  the server may have ended the forceX while the page still had its window in the old units); the forceX of a GET is
  put on the axis before `loadParams()`.
- Tests: `test/forcex_race_sim.js` with a server model that follows `src/main.c` (forcex_state, ratio 0.03,
  FORCEX_STALE_MS, `GUI_XMIN`/`GUI_XMAX` in float32), new cases 6 (POST served at once with its answer lost, retry; from s
  and from µs; 2nd click before and during the retry, 1 or 2 lost answers; also not served: 16 runs) and 7 (a zoom the
  server ignores in forcex_state, sent again later): 19/19. With the first round (`--old`) 6b, 6c and 7b fail.
- Board test (testAgent, RP2, 2026-11-13; reports in `reportes/lock-in_pid_h2/` of the Apps folder, hook `__hold` /
  `__serve` that holds the answer of the next POST(s) for 2 s): first round (`2026-11-13_1848_forcex_retry.md`, package
  of `87d1eab`): PASS with the held POST not served (2nd click at 0.3 s 3/3, at 1 s / 1.9 s 6/6, two held answers 2/2;
  kp 0 → 150 → 0 = 0, also with `__serve = true`); **FAIL** with `__serve = true` (0/2, 0 … 9.984 s). Second round
  (`2026-11-13_2312_forcex_retry2.md`, `87c2d4a`, package 2.4.15-29, tar.gz md5 `14157cd9…`): **PASS** — `__serve =
  true` from µs 7/7 (2nd click at 0.3 s ×3, 1 s ×2, 1.9 s ×2) and from s 2/2, two held answers (click at 2.3 s) 2/2,
  `__serve = false` 2/2, zoom right after the change of units 2/2; without hook kp A → B → A = A (`__serve` true and
  false), Reset zoom alternates, Config load, AUTO, Capture Lock (LOCKED) and AUTO on the capture as before, no POST
  bursts, no console errors. The hangs of nginx that trigger the retry: `reportes/nginx_close_wait.md` (§1 item 6, §2.5).
- Documentation (`doc/Structure.md`: section *A POST retried after a timeout…*; `doc/Devel.md`, READMEs, line numbers
  of `index.html` in `doc/*.md`) updated for v2.4.15 in the commit that carries the tag `v2.4.15`.

v2.4.14 - 2026-11-13 - Ramp Controller of lock_in+pid_plus 2.2.0: tabs period / freq, Ramp period in s / ms, Lock osc. screen, Reset zoom whole / half, no stale Force X (web page only, no FPGA / C change; as lock_in+pid_harmonic 2.3.31)

Port of lock_in+pid_harmonic 2.3.31 (patch `v2.3.30..v2.3.31` of its `index.html` and `test/`), which ports the Ramp
Controller of `rp_lock-in_pid_plus` v2.2.0 (rc1 … rc4, see its CHANGELOG). Only `index.html` (and its tests): the FPGA
(`fpga.bit.bin` `27a038e7…`, `red_pitaya.bit` `701094a8…`) and the sources of the C controller are those of 2.4.13
(`controllerhf.so` only rebuilt). `gen_ramp.v` is the same file as in lock_in+pid_harmonic and lock_in+pid_plus (same
md5), so: one count every `step + 1` cycles of 8 ns, triangle N = 2·(hig − low), sawtooth N = (hig − low) + 1,
T = N·(step+1)·8 ns, f = 125 MHz / (N·(step+1)); a triangle always rises after the scan floor. The resulting page differs
from lock_in+pid_harmonic 2.3.31 exactly as 2.4.13 differed from 2.3.30 (title and version only in the ported code).

- ADDED **tabs *period* / *freq*** in the Ramp Controller (only the active one visible; changing the tab ends the edit
  in progress and reloads the fields from the board; last tab in `localStorage`, key
  `lockin_ramp_tab_lock_in+pid_harmonic2`; *Ramp B factor* outside the tabs). *freq*: **Frequency** (Hz, `2.5 kHz`,
  `500 mHz`) set to the nearest reachable frequency, wheel ±1 / 10 / 100 / 1000 Hz (SHIFT / CTRL / both) with at least
  one step of the register; **Amp. p-p** / **Offset** in counts (also `mV` / `V`); changing the amplitude keeps the
  frequency set by the user.
- ADDED **Lock osc. screen** (checkbox under *Ramp B factor*; off by default, not saved): Ext Trig = Scan floor, Source
  External, Mode Normal, window 0 … T/2 (triangle: the rise) or 0 … T (sawtooth); the time zoom (box, SHIFT + wheel,
  X±) becomes new ramp limits at the same frequency; the window follows any change of the ramp; off: trigger and window
  kept, full time zoom back; Single, another Source / Ext Trig / Mode, AUTO turn it off; suspended during a Capture Lock.
- ADDED **Reset zoom alternates whole period / rising half** with Source External, Ext Trig = Scan floor and a
  triangle (without Lock osc. screen) while the zoom is not touched; with Lock osc. screen, its window. Ext Trig =
  harmonic mod. still gives one period of the modulation.
- CHANGED **Ramp period** (tab *period*) is a text field: a number is steps, `s` / `ms` / `us` give the whole period
  (nearest step); Enter / blur rewrite it in steps; not valid restores the last value; steps limited to
  0 … 2147483520 ($2^{31}-128$). The τ / f text uses the same N (the sawtooth was one step short).
- CHANGED the four ramp checkboxes in two columns; no tooltips on *Ramp period* / *Frequency*.
- FIXED "-0 mV" labels (`toFixedNz()`); implicit global loop variables; stale **Force X** of `GET /data`
  (`[FORCEX]` block, `getForceXApply()`).
- Tests: new `test/ramp_ui_sim.js` (73) and `test/forcex_race_sim.js` (7); `reset_zoom_sim.js` C1–C15 (55);
  `trig_input_units_sim.js` case 10 (43); `minor_ui_sim`, `config_load_window_sim`, `lock_capture_ui_sim`,
  `lock_ctrl_ui_sim`, `osc_presets_sim` updated. All 15 node sims pass; `auto_set_c_sim` 64/64, `trig_level_test` PASS.
- Pending: *Ramp hig / low lim* do not take mV / V; the wheel over *Ramp period* does not move the step above $2^{24}$.
- Board test (testAgent, RP2, package 2.4.14-28, 2026-11-13; `reportes/lock-in_pid_h2/2026-11-13_1749_v2414.md` in
  the Apps folder): **PASS**. Tabs (opens on *period*; *freq* 6250 Hz / 10000 / 0 with the defaults; a POST of another
  client shown in both tabs; the tab survives a reload), *freq* tab (100 Hz → step 77, 100.1603 Hz; wheel 1/10/100/1000
  Hz → 76, 70, 36, 5 and back to 77; `2.5 kHz` → 2, `500 mHz` → 15624, `500 mV` → 152 ±2048, `0.1 V` → −1229 / 2867,
  `10 kg` not sent), *Ramp period* `10 ms` → 77 (triangle) / 155 (sawtooth), no POST while typing, clamp 2147483520, no
  "-0 mV", no tooltips, Lock osc. screen (0 … 4.992 ms in triangle, box → −2394 / 13 as the model, 0 … 9.985 ms in
  sawtooth, 0.2 Hz continuous update, unchecking keeps trigger and window, Single turns it off), Reset zoom 9.984 /
  4.992 ms alternating, broken by a wheel zoom, not alternating with sawtooth (9.985) or Scan ceil (9.984); Reset zoom
  with harmonic mod. one period of the modulation, 2520·(hp+1) cycles (hp 0: 0 … 20.16 µs, hp 20: 0 … 423.36 µs), the
  same on both clicks; no console errors.
- Observation of the board test: *Force X* passed **27 of 28** second clicks of Reset zoom from an axis in seconds. In
  the standard series of 10, one click (0.3 s after the first one, before the page was instrumented) left 0 … 9.984 ms
  instead of 4.992 ms, 3 s and 6 s later; 18 more repetitions with traces of `resetZoom()`, `lockSetXWindow()`, the
  axis and the forceX of the POST answers (waits of 0.2 … 12 s) all passed, so the failure was not reproduced. It may
  be a second click that did not arrive (then the result is the expected one) or a stale forceX as in pid_plus
  2.2.0-rc3; the same code gave 10/10 in lock_in+pid_harmonic 2.3.31, sq 2.0.10 and hf 2.3.21. A zoom from t = 0
  after a forceX stayed (wheel 0 … 6.656 ms, box 0.024 … 3.890 ms, 6 s).
- The regression LOCK MODE (`lock_in+pid_harmonic2__lock_mode.json`) was **not verifiable on the current bench**:
  `dummy_simulator` on the other board ran without its low-pass filter, the scan showed the same asymmetric error Y
  (+0.06 / −0.12 V) with which lock_in+pid_harmonic 2.3.31 and hf 2.3.21 locked away from the peak, so the lock was not
  launched; v2.4.14 changes only the web page.
- Documentation (`doc/*.md`, README) updated for v2.4.14 in the commit that carries the tag `v2.4.14`.
