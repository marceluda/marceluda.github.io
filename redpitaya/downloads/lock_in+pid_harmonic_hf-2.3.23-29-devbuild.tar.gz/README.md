# Red Pitaya Lock-in+PID Application with HARMONIC High Frequency modulation

This started being a striped version of [lock-in+PID](https://github.com/marceluda/rp_lock-in_pid) project. Now it incorporated some new features that make it another App.

This High Frequency version is a copy of [Lock-in+PID Harmonic](https://github.com/marceluda/rp_lock-in_pid_h) with only one change: **The harmonic motulation signal frequencies can be set from 60 Hz to 1 MHz** (63.6 Hz to 1.04 MHz: the period of the modulation has 120 table points instead of 2520).

It is an application for the [Red Pitaya STEMlab 125-14](https://www.redpitaya.com/) board (RP): a set of
instruments built in the FPGA (oscilloscope, harmonic lock-in amplifier, two PIDs, ramp generator and
automatic lock control) to measure a system with modulation techniques and stabilize it with a feedback
loop, controlled from a web page or remotely over HTTP.

[![Example of usage](http://img.youtube.com/vi/330eYE75MYQ/0.jpg)](http://www.youtube.com/watch?v=330eYE75MYQ "Fast demosatration of usage")

![Lock captured by the App (v2.3.11, modulation at 49.6 kHz): the scan stops and the error goes to zero at t = 0](.README/lock_captured_v2.3.11.jpg)


## Version 2.3.x (Ecosystem 2.0)

Current version: **2.3.23** (branch `master`; package `archive/lock_in+pid_harmonic_hf-2.3.23-28-devbuild`).

This version is **based on the 0.3.x series (v0.3.9), with the FPGA design built in Vivado 2020.1**,
using the project structure of [RedPitaya-FPGA](https://github.com/RedPitaya/RedPitaya-FPGA)
(project `v0.94`, model `Z10`), the same port done in
[rp_lock-in_pid_h](https://github.com/marceluda/rp_lock-in_pid_h) v2.3.x: v2.3.11 has all the changes of its
v2.3.10 to v2.3.17 (lock sequence in the FPGA, Capture Lock, HTTP remote control on Ecosystem 2.0...), and
v2.3.12 the minor fixes of its v2.3.18 (same FPGA). It is
intended for the Red Pitaya **Ecosystem 2.0** (e.g. `RedPitaya_OS_2.04`; tested on 2.04-35).
Since 2026-10-15 the branch `master` holds the 2.x series; the 0.3.x series (FPGA with Vivado 2015.2), for the
0.9x / 1.0 ecosystems, stays in the tags `v0.3` .. `v0.3.9`.

- HF: the harmonic modulation has a period of 120 table points (lock_in+pid_harmonic: 2520), so its
  frequency is 125 MHz / (120 * (`gen_mod_hp` + 1)) = 1.04 MHz .. 63.6 Hz, and `gen_mod_phase` is 0..119
  (3 degrees per step). Configs of lock_in+pid_harmonic have another frequency here (hp 0 = 1.04 MHz):
  see [doc/Usage.md](doc/Usage.md#hf-notes).
- FPGA: `lock_in+pid_harmonic_hf/fpga/` (Vivado 2020.1, see
  [lock_in+pid_harmonic_hf/fpga/README.md](lock_in+pid_harmonic_hf/fpga/README.md)). Oscilloscope of the
  Ecosystem 2.0 (trigger lock, decimation widened to 20 bits: time ranges up to ~68 s), exact bus reads of the
  lock module. Same register map as lock_in+pid_harmonic.
- Lock control in the FPGA (`lock_status` at 0x1C replaces `lock_feedback`; trigger inputs registered for
  timing), **Capture Lock** and **Fire on click**: see
  [lock_control.md](lock_in+pid_harmonic_hf/doc/lock_control.md) and [lock_capture.md](lock_in+pid_harmonic_hf/doc/lock_capture.md).
- Time / Level trigger fields with units (`16.58 ms`, `20 s`, `0.1 V`); Config → load applies the time window.
- Remote control from a PC over HTTP: `resources/remote_control/http_version/control_finn.py` and
  `example_usage.py` (frequencies and phases with the HF period of 120 points). See [doc/Remote.md](doc/Remote.md).
- Tested on the board with a real lock at **49.6 kHz and 104.2 kHz** against a simulated peak; a lock at
  1.04 MHz has not been tested yet.
- Only the App itself is packaged (the `_DEBUG` and `_RELOAD` flavours were removed).
- v2.3.13: pipeline registers in the FPGA to close timing (WNS −9.3 → −0.9 ns), references delayed 1 clock to keep
  the measured phase.
- v2.3.14 (from lock_in+pid_harmonic 2.3.21–2.3.23): **Reset zoom** sets the scope to one period of the ramp (Ext Trig
  = Scan floor / Scan ceil), one period of the HF modulation (harmonic mod., 120·(hp+1) ticks) or one whole memory at
  the current Dec, and Y to −1 … 1 V (raw mode −8192 … 8192); it ends a lock capture first, and Raw Mode rescales Y.
  "Square mod." (not implemented) is no longer in the trigger menu. **Mouse wheel on the scope**: no key zooms both
  axes, **SHIFT** only time (cursor ↔), **ALT** only the Y axes (cursor ↕). **Slow scans** (windows ≥ 1.5 s, e.g. a
  30 s ramp): no samples of an older lap of the scope memory, Capture Lock with long histories, Reset zoom at
  0.98 × the period; (FPGA) a time trigger armed after the ramp was stopped waits for the next scan floor.
- v2.3.15 (from lock_in+pid_harmonic 2.3.24): **scope presets** below Ext Trig: `in1|in2`, `in1|ctrl`,
  `X|Y` (Xo, Yo), `in1|err`, `ctrl|err` and `usr` (a pair of the user: double click to choose it; saved in the browser
  and in the configs). They change only OscA/OscB (not the zoom nor the trigger). Picking an **Ext Trig** other than
  None sets the Trigger panel to External + Normal.
- v2.3.16: **Auto** waits for the trigger (Ext Trig or the level of a channel) and forces an acquisition only if none
  comes within max(0.25 s, 1.1 × window, 1.1 × period of the Ext Trig when known) + 50 ms: with Ext Trig = Scan floor
  t = 0 is the scan floor in Auto too (before, Auto triggered at once, at any phase of the scan). Also: the option **Don't turn on PIDs and Ramp on config loading** (Config dialog) is now unchecked by
  default: *Config → load* / *Load file* (and the restore after a Restart) bring back the ramp (Scan enable) and the
  PIDs as saved, so a config saved while scanning loads scanning. Checking it keeps the previous protection.
- v2.3.17 (from lock_in+pid_harmonic 2.3.27): Config dialog: **Load last config on init** (checked by default, saved in the
  browser): the App opens with the last settings used in this browser (also in a new tab); unchecked, it opens with its
  defaults. Buttons **Load last config** and **Reset to defaults** restart the App with them. The **Lock Control**
  panel is now right below Outputs.
- v2.3.18 (from lock_in+pid_harmonic 2.3.28): **Lock Control**: three small buttons **time** / **level** /
  **time+level** between Trigger Lock and Lock Now: one click on a button and one on the graph set the trigger type and
  value and fire Trigger Lock. Fixed: a click with Choose from graph + Fire on click during a POST in flight lost the new
  values or the re-lock.
- v2.3.19 (from lock_in+pid_harmonic 2.3.29): **Raw Mode**: the *Level* of the scope trigger is in ADC counts (field,
  slider, line; −8192 … 8191) and the controller writes those counts to the scope (it took them as volts: Normal /
  Single never triggered for a level other than 0); AUTO in Raw Mode with its Y range in counts (it was clipped to ±1000).
- v2.3.20 (from lock_in+pid_harmonic 2.3.30): **AUTO** puts the trigger level at the middle of the signal also with a
  calibration offset of the input (in volts it was one offset off: above in its search, below in the level it left) or
  a calibrated full scale other than 1 V (level and Y range were scaled by 1 / full scale); in Raw Mode it gives a
  whole count and half counts are rounded as the page shows them (−2.5 was shown as −2 and written as −3).
- v2.3.21 (from lock_in+pid_harmonic 2.3.31): **Ramp Controller** of lock_in+pid_plus 2.2.0 (web page only): tabs
  *period* / *freq* (Frequency in Hz with the nearest reachable value, Amp. p-p / Offset), *Ramp period* in s / ms
  (whole period), *Lock osc. screen* (scope locked on the ramp: rising half of a triangle, the time zoom sets the ramp
  limits), *Reset zoom* alternating whole period / rising half (Scan floor, triangle), no stale *Force X* of `GET /data`;
  the four ramp checkboxes in two columns, no "-0 mV" labels. With Ext Trig = harmonic mod. *Reset zoom* still gives
  one period of the HF modulation, 120·(hp+1) cycles, on every click. Same FPGA and C sources as v2.3.20; tested on
  RP2. See [doc/Usage.md](doc/Usage.md#ramp-controller) and [doc/App.md](doc/App.md#ramp-generator-scan).
- v2.3.22 (from lock_in+pid_plus 2.2.1): no lost 2nd click of *Reset zoom* when the POST of the 1st one is retried after a timeout (nginx
  hang): the answer of that POST no longer brings back the old window (*Force X*); a value changed back during a slow POST
  is no longer lost; the page checks that the server took the window it sent and sends it again if not. Web page only;
  tested on RP2 (PASS). See [doc/Structure.md](doc/Structure.md#time-window-of-the-plot-and-force-x).
- v2.3.23 (from lock_in+pid_harmonic 2.3.33 = lock_in+pid 2.2.17): **calibration of the EEPROM in the universal format**
  (5 / 6: every STEMlab 125-14 **Gen2**, and Gen1 boards recalibrated with the OS 2.x calibration App): before, IN1 read
  a constant > 30 V and IN2 ~0 V on those boards. The old format 1 is read as before, the user zone and, if it is not
  valid, the factory zone; out-of-range values give nominal ones and a warning next to the title of the page. The ADC
  offset is subtracted, as the official library (it was added), and the LV range uses its own offset; on Gen2 the DAC
  full scale is 2 V. With Raw Mode off the volts shown use the calibration (in1 / in2 their input, in1-in2 the mean,
  lock-in displays the *Lock-in input*, ctrl_A / ctrl_B and out1 / out2 the DAC, everything else nominal 8192 counts =
  1 V); Raw Mode shows the plain integers everywhere
  ([doc/Usage.md](doc/Usage.md#volts-in-the-display-calibration-v2323)). Lock-in display titles back after Raw Mode
  off. Same FPGA; not tested on a board yet. See the [CHANGELOG](CHANGELOG.md).

![Ramp Controller of v2.3.21: tab freq (100 Hz triangle, Amp. p-p 8000) and Lock osc. screen: the scope on Scan floor with the window 0 … T/2 = 4.992 ms, the rise of the ramp (red); the ramp was internal in this test, in1 (blue) is only the noise of the bench](.README/ramp_controller_lock_osc_screen_v2.3.21.jpg)
- See the [CHANGELOG](CHANGELOG.md).


## Features

- Lock-in amplifier
- in-phase and quadrature Demodulation
  - Demodulation for arbitrary phase
  - Demodulatión for double and triple frequency
- Harmonic modulation from 63.6 Hz to 1.04 MHz, added to the outputs
- Two PID filters, for loop back stabilization
- Ramp/Scan controller for response analysis, set by period or by frequency / amplitude / offset, with a *Lock osc.
  screen* mode that turns a zoom of the scope into new scan limits
- Lock control for automatic scan-stop / PID start (time, level or immediate trigger, run by the FPGA)
- Two-channel oscilloscope on any internal signal, triggered by internal events (scan floor, lock, ...)
- Streaming system for continued acquisition of two channels
- Remote control through HTTP API


**New Interface for lock-in R & Phase** :


[![New iface](http://img.youtube.com/vi/DzSK8IQkUE4/0.jpg)](http://www.youtube.com/watch?v=DzSK8IQkUE4 "New R-phase interphase")

**Decimation values of the oscilloscope**

| dec    | max oscilloscope lenght |
|--------|-------------------------|
|      1 |             0.131072 ms |
|      8 |             1.048576 ms |
|     64 |             8.388608 ms |
|    128 |            16.777216 ms |
|    256 |            33.554432 ms |
|    512 |            67.108864 ms |
|   1024 |           134.217728 ms |
|   8192 |           1.073741824 s |
|  65536 |           8.589934592 s |
| 524288 |          68.719476736 s |


## Documentation

| Document | Contents |
|---|---|
| [doc/App.md](doc/App.md) | Instruments and technical data; differences with lock_in+pid_harmonic |
| [doc/Usage.md](doc/Usage.md) | Web interface and procedures (scan, lock-in, lock at 49.6 and 104 kHz), with screenshots |
| [doc/Structure.md](doc/Structure.md) | Web page ↔ server ↔ FPGA, block diagrams |
| [doc/FPGA.md](doc/FPGA.md) | Register map |
| [doc/Remote.md](doc/Remote.md) | Remote control over HTTP, Python examples |
| [doc/Devel.md](doc/Devel.md) | Building, modifying and testing |
| [CHANGELOG.md](CHANGELOG.md) | Changes by version |

The concepts of the instruments are also explained in the documentation of the original App:
https://marceluda.github.io/rp_lock-in_pid/


## Installation

If you have a RP board you can install the **Lock-in+PID** application
by copying the `lock_in+pid_harmonic_hf` folder (that comes with this tar/zip file) to the
`/opt/redpitaya/www/apps` folder (inside the RP).

The packages are built in `archive/` (`lock_in+pid_harmonic_hf-<version>-<build>-devbuild.{zip,tar.gz}`).
UnZip / UnTar the package and execute from terminal:

```bash
./upload_app.sh rp-XXXXXX.local
```

Replace `rp-XXXXXX.local` by your RP localname or IP address. Also, you can use your own SSH client and
upload the `lock_in+pid_harmonic_hf` folder to the RedPitaya folder `/opt/redpitaya/www/apps` (file system in
read-write mode, `fpga.sh` executable). Then open `http://rp-XXXXXX.local/lock_in+pid_harmonic_hf/`.

Or, from the App folder of the sources (builds `target/` first):

```bash
make upload RPIP=rp-XXXXXX.local        # whole App
make upload_html RPIP=rp-XXXXXX.local   # only index.html, js, css
```

Then stop and start the App (or open it from the menu) so that the new controller and FPGA are loaded.

For more information about installing procedure, refer to:
https://marceluda.github.io/rp_lock-in_pid/TheApp/install/ and [doc/Devel.md](doc/Devel.md#installing-on-the-board).


## Building

To build or modify the App you need a linux development environment with:
  - Vivado 2020.1 (FPGA and `bootgen`; `lock_in+pid_harmonic_hf/fpga/Makefile` loads
    `/tools/Xilinx/Vivado/2020.1/settings64.sh` by itself, override with `VIVADO_SETTINGS=...`)
  - gcc-linaro-4.9-2015.02-3-x86_64_arm-linux-gnueabihf (installed on `/opt/linaro/gcc-linaro-4.9-2015.02-3-x86_64_arm-linux-gnueabihf/`)
  - (the 0.3.x series, tags `v0.3` .. `v0.3.9`, used Vivado 2015.2; `settings.sh` still loads it if present)

The App was based on code from project:
https://github.com/RedPitaya/RedPitaya/tree/release-v0.95/apps-free/scope

Run on terminal:

```bash
source settings.sh
LANG=C make          # controller, c/ tools, FPGA (if changed) and packages in archive/
```

Parts (from the root folder):

```bash
make -C lock_in+pid_harmonic_hf app        # C controller + c/ tools (cross compiled)
make -C lock_in+pid_harmonic_hf c_tools    # only the c/ tools (lock, osc, streaming)
make -C lock_in+pid_harmonic_hf fpga       # FPGA with Vivado 2020.1 (red_pitaya.bit, fpga.bit.bin)
make clean                                 # clean all (also: clean_app, clean_fpga in lock_in+pid_harmonic_hf)
```

The FPGA can also be built from `lock_in+pid_harmonic_hf/fpga` (`make`, `make project`, `make clean`); its
Makefile loads Vivado 2020.1 by itself. Requirements, all the targets, tests and details:
[doc/Devel.md](doc/Devel.md).


## License and citation

GPL-3.0 (see [LICENSE](LICENSE)). If you use this software, please cite: M. A. Luda, doi
[10.1063/1.5080345](https://doi.org/10.1063/1.5080345).
