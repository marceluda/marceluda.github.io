# Red Pitaya Lock-in+PID Application with HARMONIC modulation with TWO demodulation channels


This project is based in [lock-in+PID Harmonic](https://github.com/marceluda/rp_lock-in_pid_h)


Video from lock-in+PID Harmonic version:

[![Example of usage](http://img.youtube.com/vi/330eYE75MYQ/0.jpg)](http://www.youtube.com/watch?v=330eYE75MYQ "Fast demosatration of usage")


## Features

- **TWO** Lock-in amplifier
- in-phase and quadrature Demodulation
  - Demodulation for arbitrary phase
  - Demodulatión for double and triple frequency
- Two PID filters, for loop back stabilization
- Ramp/Scan controller for response analysis
- Lock control for automatic scan-stop / PID start
- Streaming system for continued acquisition of two channels
- Remote control through HTTP API
 

**More decimaion values**

| dec    | max oscilloscope lenght |
|--------|-------------------------|
|      1 |             0.131072 ms |
|      8 |             1.048576 ms |
|     64 |             8.388608 ms |
|    128 |            16.777216 ms |
|    256 |            33.554432 ms |
|    512 |            67.108864 ms |
|   1024 |           134.217728 ms |
|   8192 |           1.073741824 s |
|  65536 |           8.589934592 s |
| 524288 |          68.719476736 s |


## Lock-in and PID application for RedPitaya environment

This is an application built for the [Red Pitaya STEMlab 125-14](https://www.redpitaya.com/) board (RP).
The board is closed-hardware and open-software. You can buy the board and build your own software.

If you have a RP board you can install the **Lock-in+PID** application
by copying the `lock_in+pid_harmonic2` folder (that comes with this tar/zip file) to the
`/opt/redpitaya/www/apps` folder (inside the RP).

For more information about installing procedure, refer to:
https://marceluda.github.io/rp_lock-in_pid/TheApp/install/


# Development

To build or modify the App you need a linux development environment with:
  - Vivado 2015.2
  - gcc-linaro-4.9-2015.02-3-x86_64_arm-linux-gnueabihf (installed on `/opt/linaro/gcc-linaro-4.9-2015.02-3-x86_64_arm-linux-gnueabihf/`)


The App was based on code from project:
https://github.com/RedPitaya/RedPitaya/tree/release-v0.95/apps-free/scope

## Software requirements

You will need the following to build the Red Pitaya components:

1. Various development packages:

```bash
sudo apt-get install make u-boot-tools curl xz-utils nano
```

2. a. Xilinx [Vivado 2015.2](https://www.xilinx.com/support/download/index.html/content/xilinx/en/downloadNav/vivado-design-tools/archive.html) FPGA development tools. The SDK (bare metal toolchain) must also be installed, be careful during the install process to select it. Preferably use the default install location.

2. b. The new OS version 2.0 requires a command that is included in more recent version of Vivado: Xilinx [Vivado 2020.1](https://www.xilinx.com/support/download/index.html/content/xilinx/en/downloadNav/vivado-design-tools/archive.html). More info in [Red Pitaya documentation](https://redpitaya-knowledge-base.readthedocs.io/en/latest/learn_fpga/3_vivado_env/tutorfpga1.html)

3. Linaro [ARM toolchain](https://releases.linaro.org/14.11/components/toolchain/binaries/arm-linux-gnueabihf/) for cross compiling Linux applications. We recommend to install it to `/opt/linaro/` since build process instructions relly on it.

```bash
# TOOLCHAIN="http://releases.linaro.org/14.11/components/toolchain/binaries/arm-linux-gnueabihf/gcc-linaro-4.9-2014.11-x86_64_arm-linux-gnueabihf.tar.xz"
TOOLCHAIN="http://releases.linaro.org/15.02/components/toolchain/binaries/arm-linux-gnueabihf/gcc-linaro-4.9-2015.02-3-x86_64_arm-linux-gnueabihf.tar.xz"
curl -O $TOOLCHAIN
sudo mkdir -p /opt/linaro
sudo chown $USER:$USER /opt/linaro
tar -xpf *linaro*.tar.xz -C /opt/linaro
```


**NOTE:** you can skip installing Vivado tools, if you only wish to compile user space software.

4. Missing `gmake` path

Vivado requires a `gmake` executable which does not exist on Ubuntu. It is necessary to create a symbolic link to the regular `make` executable.

```bash
sudo ln -s /usr/bin/make /usr/bin/gmake
```

5. On Ubuntu Linux you also need:

```bash
sudo apt-get install make u-boot-tools curl xz-utils
sudo apt-get install libx32gcc-4.8-dev
sudo apt-get install libc6-dev-i386
```

The building was tested on Ubuntu 24.04.02 Linux x86_64 


## Building



Run on terminal:

```bash
source settings.sh
make
```

Or form App folder `lock_in+pid_harmonic2` :

```bash
source ../settings.sh
```


and then...

For web controller building:

```bash
make app
```

For FPGA implementation:

```bash
make fpga
```


For tar.gz packaging

```bash
make tar
```

For cleaning:

```bash
make clean       # clean all
make clean_app   # clean only C objects
make clean_fpga  # clean only FPGA implementation temp files and .bin
```


# Upload App to Red Pitaya device

UnZip / UnTar the App folder. Execute from terminal:

```bash
./upload_app.sh rp-XXXXXX.local
```

Replace `rp-XXXXXX.local` by your RP localname or IP address

Also, you can use your own SSH client and upload the `lock_in+pid_harmonic2` folder the the
RedPiaya folder: `/opt/redpitaya/www/apps`
